# Descriptif du projet

Média : Open Odyssey, Presse Océan, Terri(s)toires

Sujet : Open Odyssey - Déchets urbains

Dans quelle mesure le quartier de Bellevue s’inscrit il dans une démarche de développement durable grâce au mouvement environnement solidaire ?

Equipe : Tomorrow

Patricipants :

- AGR : Romain CELTON, Timothée RALIRAVAKA, Sara THION
- Polytech : Jean PORTALIS, Omar DIOUF, Quentin MAISONNEUVE, Benjamin LANDRY
- SciencesCom : Pierre FORGET, Lou DUBAR, Julien BECCU

# Installation

# Informations complémentaires
