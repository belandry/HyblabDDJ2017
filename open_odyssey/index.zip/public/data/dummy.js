var objet = {  
  "Personne isolé":
    [
      {
        "nom": "Bellevue Nantes St Herblain",
        "valeur": 19424
      },
      {
        "nom": "Dervaillières",
        "valeur": 4973
      },
      {
        "nom": "Malakoff",
        "valeur": 3085
      },
      {
        "nom": "Breil Malville",
        "valeur": 3932
      },
      {
        "nom": "Quartier Nord",
        "valeur": 11594
      },
      {
        "nom": "Port Boyer",
        "valeur": 2179
      },
      {
        "nom": "Bottière pin sec",
        "valeur": 5348
      },
      {
        "nom": "Clos Toreau",
        "valeur": 2498
      },
      {
        "nom": "La Halveque",
        "valeur": 4727
      },
      {
        "nom": "Sillon de Bretagne",
        "valeur": 1843
      },
      {
        "nom": "Château",
        "valeur": 4035
      },
      {
        "nom": "Plaisance",
        "valeur": 2470
      },
      {
        "nom": "Ranzay grand clos",
        "valeur": 2664
      }
    ],

    "Revenu médian":
    [
      {
        "nom": "Bellevue Nantes St Herblain 1er",
        "valeur": 163
      },
      {
        "nom": "Nantes Métropole 1er",
        "valeur": 679
      },
      {
        "nom": "Bellevue Nantes St Herblain",
        "valeur": 1002
      },
      {
        "nom": "Nantes Métropole",
        "valeur": 1752
      }
    ],

    "Ménages composés de personne seules à bas revenu":
    [
      {
        "nom": "Bellevue Nantes St Herblain 1er",
        "valeur": 0.33
      },
      {
        "nom": "Nantes Métropole 1er",
        "valeur": 0.192
      }
    ]
};
